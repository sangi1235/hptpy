import { getUncachableStripeClient } from './stripeClient';

async function seedProducts() {
  console.log('Starting Stripe product seed...');
  const stripe = await getUncachableStripeClient();

  const products = [
    {
      name: 'Wireless Noise Cancelling Headphones',
      description: 'Premium over-ear headphones with active noise cancellation, 30-hour battery life, and crystal clear audio.',
      images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800'],
      metadata: { brand: 'SoundMax', category: 'electronics', featured: 'true' },
      price: 29999,
    },
    {
      name: 'Ultra-Thin Laptop 15 Pro',
      description: 'Powerful yet lightweight laptop with 15-inch Retina display, M2 chip, 16GB RAM, and 512GB SSD.',
      images: ['https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800'],
      metadata: { brand: 'TechPro', category: 'electronics', featured: 'true' },
      price: 149999,
    },
    {
      name: 'Smart Watch Series 8',
      description: 'Advanced smartwatch with health monitoring, GPS, always-on display, and 7-day battery life.',
      images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800'],
      metadata: { brand: 'TechPro', category: 'electronics', featured: 'true' },
      price: 39999,
    },
    {
      name: '4K Ultra HD Smart TV 55"',
      description: 'Stunning 55-inch 4K display with HDR, smart features, built-in streaming apps, and voice control.',
      images: ['https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800'],
      metadata: { brand: 'VisionPlus', category: 'electronics' },
      price: 69999,
    },
    {
      name: 'Wireless Bluetooth Speaker',
      description: 'Portable speaker with 360-degree sound, waterproof design, and 12-hour battery life.',
      images: ['https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800'],
      metadata: { brand: 'SoundMax', category: 'electronics' },
      price: 7999,
    },
    {
      name: 'Premium Leather Jacket',
      description: 'Handcrafted genuine leather jacket with satin lining. Timeless design that never goes out of style.',
      images: ['https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800'],
      metadata: { brand: 'UrbanStyle', category: 'fashion', featured: 'true' },
      price: 34999,
    },
    {
      name: 'Classic Running Sneakers',
      description: 'Comfortable and stylish running shoes with cushioned soles and breathable mesh upper.',
      images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800'],
      metadata: { brand: 'SportFlex', category: 'fashion', featured: 'true' },
      price: 12999,
    },
    {
      name: 'Designer Sunglasses',
      description: 'UV400 protection polarized lenses with titanium frame. Includes premium case.',
      images: ['https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800'],
      metadata: { brand: 'LuxeVision', category: 'fashion' },
      price: 19999,
    },
    {
      name: 'Modern Minimalist Desk Lamp',
      description: 'LED desk lamp with adjustable brightness, color temperature control, and USB charging port.',
      images: ['https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800'],
      metadata: { brand: 'HomeLight', category: 'home', featured: 'true' },
      price: 8999,
    },
    {
      name: 'Ergonomic Office Chair',
      description: 'Premium office chair with lumbar support, adjustable armrests, and breathable mesh back.',
      images: ['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800'],
      metadata: { brand: 'ComfortPro', category: 'home', featured: 'true' },
      price: 44999,
    },
    {
      name: 'Professional Yoga Mat',
      description: 'Extra thick eco-friendly yoga mat with alignment lines and carrying strap.',
      images: ['https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800'],
      metadata: { brand: 'ZenFit', category: 'sports', featured: 'true' },
      price: 6999,
    },
    {
      name: 'Mountain Hiking Backpack 45L',
      description: 'Durable waterproof hiking backpack with multiple compartments and hydration system compatible.',
      images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800'],
      metadata: { brand: 'TrailMaster', category: 'sports', featured: 'true' },
      price: 14999,
    },
    {
      name: 'Premium Skincare Set',
      description: 'Complete skincare routine including cleanser, toner, serum, and moisturizer. For all skin types.',
      images: ['https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800'],
      metadata: { brand: 'GlowUp', category: 'beauty', featured: 'true' },
      price: 12999,
    },
    {
      name: 'Electric Massage Gun',
      description: 'Deep tissue percussion massager with 6 heads and 30 speed levels. Perfect for muscle recovery.',
      images: ['https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800'],
      metadata: { brand: 'RelaxPro', category: 'beauty' },
      price: 18999,
    },
  ];

  for (const prod of products) {
    try {
      const product = await stripe.products.create({
        name: prod.name,
        description: prod.description,
        images: prod.images,
        metadata: prod.metadata,
        active: true,
      });

      await stripe.prices.create({
        product: product.id,
        unit_amount: prod.price,
        currency: 'usd',
      });

      console.log(`Created: ${product.name}`);
    } catch (error: any) {
      console.log(`Skipping ${prod.name} (likely already exists)`);
    }
  }

  console.log('Stripe product seed completed!');
}

seedProducts()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Seed failed:', err);
    process.exit(1);
  });
