import {
  users,
  categories,
  products,
  productVariants,
  carts,
  cartItems,
  orders,
  orderItems,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Product,
  type InsertProduct,
  type ProductVariant,
  type InsertProductVariant,
  type Cart,
  type CartItem,
  type InsertCartItem,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type CartWithItems,
  type CartItemWithProduct,
  type ProductWithCategory,
  type OrderWithItems,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, ilike, or, inArray, asc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Product operations
  getProducts(filters?: {
    categoryId?: number;
    categorySlug?: string;
    featured?: boolean;
    search?: string;
    inStock?: boolean;
    sort?: string;
    limit?: number;
  }): Promise<Product[]>;
  getProductBySlug(slug: string): Promise<ProductWithCategory | undefined>;
  getProductById(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Product variant operations
  getProductVariants(productId: number): Promise<ProductVariant[]>;
  createProductVariant(variant: InsertProductVariant): Promise<ProductVariant>;
  deleteProductVariant(id: number): Promise<boolean>;
  
  // Cart operations
  getCart(userId?: string, sessionId?: string): Promise<CartWithItems | undefined>;
  getOrCreateCart(userId?: string, sessionId?: string): Promise<Cart>;
  addToCart(cartId: number, item: InsertCartItem): Promise<CartItem>;
  updateCartItem(itemId: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(itemId: number): Promise<boolean>;
  clearCart(cartId: number): Promise<boolean>;
  
  // Order operations
  getOrders(userId: string): Promise<OrderWithItems[]>;
  getOrderById(id: number): Promise<OrderWithItems | undefined>;
  getAllOrders(limit?: number): Promise<OrderWithItems[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Admin stats
  getAdminStats(): Promise<{
    totalProducts: number;
    totalOrders: number;
    totalRevenue: number;
    pendingOrders: number;
  }>;

  // Stripe operations
  updateUserStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User | undefined>;
  getUserByStripeId(stripeCustomerId: string): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name));
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [created] = await db.insert(categories).values(category).returning();
    return created;
  }

  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return updated;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return true;
  }

  // Product operations
  async getProducts(filters?: {
    categoryId?: number;
    categorySlug?: string;
    featured?: boolean;
    search?: string;
    inStock?: boolean;
    sort?: string;
    limit?: number;
  }): Promise<Product[]> {
    let query = db.select().from(products);
    const conditions = [];

    if (filters?.categoryId) {
      conditions.push(eq(products.categoryId, filters.categoryId));
    }

    if (filters?.categorySlug) {
      const category = await this.getCategoryBySlug(filters.categorySlug);
      if (category) {
        conditions.push(eq(products.categoryId, category.id));
      }
    }

    if (filters?.featured) {
      conditions.push(eq(products.featured, true));
    }

    if (filters?.inStock) {
      conditions.push(sql`${products.stock} > 0`);
    }

    if (filters?.search) {
      conditions.push(
        or(
          ilike(products.name, `%${filters.search}%`),
          ilike(products.description, `%${filters.search}%`),
          ilike(products.brand, `%${filters.search}%`)
        )
      );
    }

    // Only show active products
    conditions.push(eq(products.isActive, true));

    let finalQuery = conditions.length > 0
      ? query.where(and(...conditions))
      : query;

    // Apply sorting
    if (filters?.sort === "price-low") {
      finalQuery = finalQuery.orderBy(asc(products.price));
    } else if (filters?.sort === "price-high") {
      finalQuery = finalQuery.orderBy(desc(products.price));
    } else if (filters?.sort === "name") {
      finalQuery = finalQuery.orderBy(asc(products.name));
    } else {
      finalQuery = finalQuery.orderBy(desc(products.createdAt));
    }

    if (filters?.limit) {
      finalQuery = finalQuery.limit(filters.limit);
    }

    return await finalQuery;
  }

  async getProductBySlug(slug: string): Promise<ProductWithCategory | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.slug, slug));
    
    if (!product) return undefined;

    const category = product.categoryId 
      ? await this.getCategoryById(product.categoryId)
      : undefined;

    const variants = await this.getProductVariants(product.id);

    return {
      ...product,
      category: category || null,
      variants,
    };
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    await db.delete(products).where(eq(products.id, id));
    return true;
  }

  // Product variant operations
  async getProductVariants(productId: number): Promise<ProductVariant[]> {
    return await db
      .select()
      .from(productVariants)
      .where(eq(productVariants.productId, productId));
  }

  async createProductVariant(variant: InsertProductVariant): Promise<ProductVariant> {
    const [created] = await db.insert(productVariants).values(variant).returning();
    return created;
  }

  async deleteProductVariant(id: number): Promise<boolean> {
    await db.delete(productVariants).where(eq(productVariants.id, id));
    return true;
  }

  // Cart operations
  async getCart(userId?: string, sessionId?: string): Promise<CartWithItems | undefined> {
    let cart: Cart | undefined;

    if (userId) {
      const [found] = await db.select().from(carts).where(eq(carts.userId, userId));
      cart = found;
    } else if (sessionId) {
      const [found] = await db.select().from(carts).where(eq(carts.sessionId, sessionId));
      cart = found;
    }

    if (!cart) return undefined;

    const items = await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.cartId, cart.id));

    const itemsWithProducts: CartItemWithProduct[] = await Promise.all(
      items.map(async (item) => {
        const [product] = await db
          .select()
          .from(products)
          .where(eq(products.id, item.productId));
        
        let variant = null;
        if (item.variantId) {
          const [v] = await db
            .select()
            .from(productVariants)
            .where(eq(productVariants.id, item.variantId));
          variant = v || null;
        }

        return {
          ...item,
          product,
          variant,
        };
      })
    );

    return {
      ...cart,
      items: itemsWithProducts,
    };
  }

  async getOrCreateCart(userId?: string, sessionId?: string): Promise<Cart> {
    let cart: Cart | undefined;

    if (userId) {
      const [found] = await db.select().from(carts).where(eq(carts.userId, userId));
      cart = found;
    } else if (sessionId) {
      const [found] = await db.select().from(carts).where(eq(carts.sessionId, sessionId));
      cart = found;
    }

    if (!cart) {
      const [created] = await db
        .insert(carts)
        .values({ userId, sessionId })
        .returning();
      cart = created;
    }

    return cart;
  }

  async addToCart(cartId: number, item: InsertCartItem): Promise<CartItem> {
    // Check if item already exists
    const conditions = [
      eq(cartItems.cartId, cartId),
      eq(cartItems.productId, item.productId),
    ];
    
    if (item.variantId) {
      conditions.push(eq(cartItems.variantId, item.variantId));
    }

    const [existing] = await db
      .select()
      .from(cartItems)
      .where(and(...conditions));

    if (existing) {
      const [updated] = await db
        .update(cartItems)
        .set({ quantity: existing.quantity + item.quantity })
        .where(eq(cartItems.id, existing.id))
        .returning();
      return updated;
    }

    const [created] = await db.insert(cartItems).values({ ...item, cartId }).returning();
    return created;
  }

  async updateCartItem(itemId: number, quantity: number): Promise<CartItem | undefined> {
    const [updated] = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, itemId))
      .returning();
    return updated;
  }

  async removeCartItem(itemId: number): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.id, itemId));
    return true;
  }

  async clearCart(cartId: number): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.cartId, cartId));
    return true;
  }

  // Order operations
  async getOrders(userId: string): Promise<OrderWithItems[]> {
    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));

    return await Promise.all(
      userOrders.map(async (order) => {
        const items = await db
          .select()
          .from(orderItems)
          .where(eq(orderItems.orderId, order.id));
        return { ...order, items };
      })
    );
  }

  async getOrderById(id: number): Promise<OrderWithItems | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, order.id));

    return { ...order, items };
  }

  async getAllOrders(limit?: number): Promise<OrderWithItems[]> {
    let query = db.select().from(orders).orderBy(desc(orders.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }

    const allOrders = await query;

    return await Promise.all(
      allOrders.map(async (order) => {
        const items = await db
          .select()
          .from(orderItems)
          .where(eq(orderItems.orderId, order.id));
        return { ...order, items };
      })
    );
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [created] = await db.insert(orders).values(order).returning();
    return created;
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const [created] = await db.insert(orderItems).values(item).returning();
    return created;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [updated] = await db
      .update(orders)
      .set({ status, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updated;
  }

  // Admin stats
  async getAdminStats(): Promise<{
    totalProducts: number;
    totalOrders: number;
    totalRevenue: number;
    pendingOrders: number;
  }> {
    const [productCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(products);

    const [orderCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders);

    const [revenueResult] = await db
      .select({ total: sql<string>`COALESCE(SUM(total::numeric), 0)` })
      .from(orders)
      .where(eq(orders.status, "delivered"));

    const [pendingCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "pending"));

    return {
      totalProducts: productCount?.count || 0,
      totalOrders: orderCount?.count || 0,
      totalRevenue: parseFloat(revenueResult?.total || "0"),
      pendingOrders: pendingCount?.count || 0,
    };
  }

  // Stripe operations
  async updateUserStripeCustomerId(userId: string, stripeCustomerId: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getUserByStripeId(stripeCustomerId: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.stripeCustomerId, stripeCustomerId));
    return user;
  }
}

export const storage = new DatabaseStorage();
