import { db } from "./db";
import { categories, products, users } from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Starting seed...");

  // Check if categories already exist
  const existingCategories = await db.select().from(categories);
  if (existingCategories.length > 0) {
    console.log("Data already exists, skipping seed");
    return;
  }

  // Seed categories
  const categoryData = [
    { name: "Electronics", slug: "electronics", description: "Phones, laptops, tablets and more", sortOrder: 1 },
    { name: "Fashion", slug: "fashion", description: "Clothing, shoes, and accessories", sortOrder: 2 },
    { name: "Home & Garden", slug: "home-garden", description: "Furniture, decor, and outdoor items", sortOrder: 3 },
    { name: "Sports & Outdoors", slug: "sports-outdoors", description: "Sports equipment and outdoor gear", sortOrder: 4 },
    { name: "Beauty & Health", slug: "beauty-health", description: "Skincare, makeup, and wellness products", sortOrder: 5 },
    { name: "Books & Media", slug: "books-media", description: "Books, movies, music, and games", sortOrder: 6 },
  ];

  const insertedCategories = await db.insert(categories).values(categoryData).returning();
  console.log(`Inserted ${insertedCategories.length} categories`);

  // Get category IDs
  const electronicsId = insertedCategories.find(c => c.slug === "electronics")?.id;
  const fashionId = insertedCategories.find(c => c.slug === "fashion")?.id;
  const homeId = insertedCategories.find(c => c.slug === "home-garden")?.id;
  const sportsId = insertedCategories.find(c => c.slug === "sports-outdoors")?.id;
  const beautyId = insertedCategories.find(c => c.slug === "beauty-health")?.id;
  const booksId = insertedCategories.find(c => c.slug === "books-media")?.id;

  // Seed products
  const productData = [
    // Electronics
    {
      name: "Wireless Noise Cancelling Headphones",
      slug: "wireless-headphones-pro",
      description: "Premium over-ear headphones with active noise cancellation, 30-hour battery life, and crystal clear audio. Perfect for music lovers and professionals.",
      price: "299.99",
      compareAtPrice: "349.99",
      categoryId: electronicsId,
      brand: "SoundMax",
      sku: "SM-WH-001",
      stock: 45,
      images: ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Ultra-Thin Laptop 15 Pro",
      slug: "ultra-thin-laptop-15",
      description: "Powerful yet lightweight laptop with 15-inch Retina display, M2 chip, 16GB RAM, and 512GB SSD. Perfect for work and creativity.",
      price: "1499.99",
      compareAtPrice: "1699.99",
      categoryId: electronicsId,
      brand: "TechPro",
      sku: "TP-LT-015",
      stock: 20,
      images: ["https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Smart Watch Series 8",
      slug: "smart-watch-series-8",
      description: "Advanced smartwatch with health monitoring, GPS, always-on display, and 7-day battery life. Water resistant up to 50m.",
      price: "399.99",
      categoryId: electronicsId,
      brand: "TechPro",
      sku: "TP-SW-008",
      stock: 60,
      images: ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "4K Ultra HD Smart TV 55\"",
      slug: "4k-smart-tv-55",
      description: "Stunning 55-inch 4K display with HDR, smart features, built-in streaming apps, and voice control.",
      price: "699.99",
      compareAtPrice: "899.99",
      categoryId: electronicsId,
      brand: "VisionPlus",
      sku: "VP-TV-055",
      stock: 15,
      images: ["https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800"],
      featured: false,
      isActive: true,
    },
    {
      name: "Wireless Bluetooth Speaker",
      slug: "wireless-bluetooth-speaker",
      description: "Portable speaker with 360-degree sound, waterproof design, and 12-hour battery life.",
      price: "79.99",
      categoryId: electronicsId,
      brand: "SoundMax",
      sku: "SM-BS-002",
      stock: 100,
      images: ["https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800"],
      featured: false,
      isActive: true,
    },
    // Fashion
    {
      name: "Premium Leather Jacket",
      slug: "premium-leather-jacket",
      description: "Handcrafted genuine leather jacket with satin lining. Timeless design that never goes out of style.",
      price: "349.99",
      compareAtPrice: "449.99",
      categoryId: fashionId,
      brand: "UrbanStyle",
      sku: "US-LJ-001",
      stock: 25,
      images: ["https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Classic Running Sneakers",
      slug: "classic-running-sneakers",
      description: "Comfortable and stylish running shoes with cushioned soles and breathable mesh upper.",
      price: "129.99",
      categoryId: fashionId,
      brand: "SportFlex",
      sku: "SF-RS-001",
      stock: 80,
      images: ["https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Designer Sunglasses",
      slug: "designer-sunglasses",
      description: "UV400 protection polarized lenses with titanium frame. Includes premium case.",
      price: "199.99",
      categoryId: fashionId,
      brand: "LuxeVision",
      sku: "LV-SG-001",
      stock: 40,
      images: ["https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800"],
      featured: false,
      isActive: true,
    },
    // Home & Garden
    {
      name: "Modern Minimalist Desk Lamp",
      slug: "modern-desk-lamp",
      description: "LED desk lamp with adjustable brightness, color temperature control, and USB charging port.",
      price: "89.99",
      categoryId: homeId,
      brand: "HomeLight",
      sku: "HL-DL-001",
      stock: 55,
      images: ["https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Ergonomic Office Chair",
      slug: "ergonomic-office-chair",
      description: "Premium office chair with lumbar support, adjustable armrests, and breathable mesh back.",
      price: "449.99",
      compareAtPrice: "549.99",
      categoryId: homeId,
      brand: "ComfortPro",
      sku: "CP-OC-001",
      stock: 30,
      images: ["https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Indoor Plant Collection Set",
      slug: "indoor-plant-set",
      description: "Set of 3 low-maintenance indoor plants in decorative pots. Perfect for home or office.",
      price: "59.99",
      categoryId: homeId,
      brand: "GreenLife",
      sku: "GL-IP-003",
      stock: 35,
      images: ["https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800"],
      featured: false,
      isActive: true,
    },
    // Sports & Outdoors
    {
      name: "Professional Yoga Mat",
      slug: "professional-yoga-mat",
      description: "Extra thick eco-friendly yoga mat with alignment lines and carrying strap.",
      price: "69.99",
      categoryId: sportsId,
      brand: "ZenFit",
      sku: "ZF-YM-001",
      stock: 70,
      images: ["https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Mountain Hiking Backpack 45L",
      slug: "hiking-backpack-45l",
      description: "Durable waterproof hiking backpack with multiple compartments and hydration system compatible.",
      price: "149.99",
      categoryId: sportsId,
      brand: "TrailMaster",
      sku: "TM-BP-045",
      stock: 40,
      images: ["https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800"],
      featured: true,
      isActive: true,
    },
    // Beauty & Health
    {
      name: "Premium Skincare Set",
      slug: "premium-skincare-set",
      description: "Complete skincare routine including cleanser, toner, serum, and moisturizer. For all skin types.",
      price: "129.99",
      compareAtPrice: "159.99",
      categoryId: beautyId,
      brand: "GlowUp",
      sku: "GU-SS-001",
      stock: 50,
      images: ["https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Electric Massage Gun",
      slug: "electric-massage-gun",
      description: "Deep tissue percussion massager with 6 heads and 30 speed levels. Perfect for muscle recovery.",
      price: "189.99",
      categoryId: beautyId,
      brand: "RelaxPro",
      sku: "RP-MG-001",
      stock: 45,
      images: ["https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800"],
      featured: false,
      isActive: true,
    },
    // Books & Media
    {
      name: "Bestseller Fiction Collection",
      slug: "bestseller-fiction-collection",
      description: "Set of 5 award-winning fiction novels from top contemporary authors. Hardcover editions.",
      price: "89.99",
      compareAtPrice: "124.99",
      categoryId: booksId,
      brand: "ReadMore",
      sku: "RM-BK-005",
      stock: 60,
      images: ["https://images.unsplash.com/photo-1512820790803-83ca734da794?w=800"],
      featured: true,
      isActive: true,
    },
    {
      name: "Premium Vinyl Record Player",
      slug: "vinyl-record-player",
      description: "Vintage-style turntable with built-in speakers, Bluetooth connectivity, and USB recording.",
      price: "249.99",
      categoryId: booksId,
      brand: "RetroSound",
      sku: "RS-VP-001",
      stock: 25,
      images: ["https://images.unsplash.com/photo-1539006748986-210a2f6cd708?w=800"],
      featured: false,
      isActive: true,
    },
  ];

  const insertedProducts = await db.insert(products).values(productData).returning();
  console.log(`Inserted ${insertedProducts.length} products`);

  console.log("Seed completed successfully!");
}

seed()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  });
