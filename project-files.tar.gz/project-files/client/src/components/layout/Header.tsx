import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, User, Menu, X, ChevronDown, Package, LogOut, Settings, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { CartSheet } from "@/components/cart/CartSheet";
import type { Category } from "@shared/schema";

interface HeaderProps {
  categories?: Category[];
  onSearch?: (query: string) => void;
}

export function Header({ categories = [], onSearch }: HeaderProps) {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const { itemCount } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);

  const topCategories = categories.filter(c => !c.parentId).slice(0, 8);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      onSearch?.(searchQuery);
    }
  };

  const getUserInitials = () => {
    if (!user) return "U";
    const first = user.firstName?.[0] || "";
    const last = user.lastName?.[0] || "";
    return (first + last).toUpperCase() || user.email?.[0]?.toUpperCase() || "U";
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background border-b">
      {/* Top bar */}
      <div className="bg-muted/50 border-b">
        <div className="container mx-auto px-4 h-9 flex items-center justify-between text-xs text-muted-foreground">
          <div className="hidden sm:flex items-center gap-4">
            <span>Free shipping on orders over $50</span>
            <span className="text-border">|</span>
            <span>30-day easy returns</span>
          </div>
          <div className="flex items-center gap-4 ml-auto">
            <Link href="/help" className="hover:text-foreground transition-colors" data-testid="link-help">
              Help Center
            </Link>
            <Link href="/track-order" className="hover:text-foreground transition-colors" data-testid="link-track-order">
              Track Order
            </Link>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center gap-4">
          {/* Mobile menu button */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <div className="flex flex-col gap-4 mt-6">
                <h3 className="font-semibold text-lg">Categories</h3>
                <nav className="flex flex-col gap-2">
                  {topCategories.map((category) => (
                    <Link
                      key={category.id}
                      href={`/category/${category.slug}`}
                      className="flex items-center gap-2 px-3 py-2 rounded-md hover-elevate"
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid={`link-mobile-category-${category.slug}`}
                    >
                      {category.name}
                    </Link>
                  ))}
                </nav>
                <div className="border-t pt-4 mt-4">
                  {isAuthenticated ? (
                    <>
                      <Link
                        href="/orders"
                        className="flex items-center gap-2 px-3 py-2 rounded-md hover-elevate"
                        onClick={() => setMobileMenuOpen(false)}
                        data-testid="link-mobile-orders"
                      >
                        <Package className="h-4 w-4" />
                        My Orders
                      </Link>
                      {user?.isAdmin && (
                        <Link
                          href="/admin"
                          className="flex items-center gap-2 px-3 py-2 rounded-md hover-elevate"
                          onClick={() => setMobileMenuOpen(false)}
                          data-testid="link-mobile-admin"
                        >
                          <LayoutDashboard className="h-4 w-4" />
                          Admin Dashboard
                        </Link>
                      )}
                      <a
                        href="/api/logout"
                        className="flex items-center gap-2 px-3 py-2 rounded-md hover-elevate text-destructive"
                        data-testid="link-mobile-logout"
                      >
                        <LogOut className="h-4 w-4" />
                        Sign Out
                      </a>
                    </>
                  ) : (
                    <a
                      href="/api/login"
                      className="flex items-center gap-2 px-3 py-2 rounded-md hover-elevate"
                      data-testid="link-mobile-login"
                    >
                      <User className="h-4 w-4" />
                      Sign In
                    </a>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0" data-testid="link-logo">
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
              <Package className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl hidden sm:block">ShopHub</span>
          </Link>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 h-10 w-full"
                data-testid="input-search"
              />
            </div>
          </form>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* User menu */}
            {isLoading ? (
              <div className="h-9 w-9 rounded-full bg-muted animate-pulse" />
            ) : isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-user-menu">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
                      <AvatarFallback className="text-xs">{getUserInitials()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">
                      {user?.firstName ? `${user.firstName} ${user.lastName || ""}` : user?.email}
                    </p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/orders" className="flex items-center gap-2 cursor-pointer" data-testid="link-orders">
                      <Package className="h-4 w-4" />
                      My Orders
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center gap-2 cursor-pointer" data-testid="link-profile">
                      <Settings className="h-4 w-4" />
                      Account Settings
                    </Link>
                  </DropdownMenuItem>
                  {user?.isAdmin && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/admin" className="flex items-center gap-2 cursor-pointer" data-testid="link-admin">
                          <LayoutDashboard className="h-4 w-4" />
                          Admin Dashboard
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a href="/api/logout" className="flex items-center gap-2 cursor-pointer text-destructive" data-testid="link-logout">
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="ghost" asChild data-testid="button-login">
                <a href="/api/login" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">Sign In</span>
                </a>
              </Button>
            )}

            {/* Cart button */}
            <Sheet open={cartOpen} onOpenChange={setCartOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="relative" data-testid="button-cart">
                  <ShoppingCart className="h-5 w-5" />
                  {itemCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                    >
                      {itemCount > 99 ? "99+" : itemCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <CartSheet onClose={() => setCartOpen(false)} />
            </Sheet>
          </div>
        </div>
      </div>

      {/* Category navigation */}
      <nav className="hidden lg:block border-t bg-background">
        <div className="container mx-auto px-4">
          <ul className="flex items-center gap-1 overflow-x-auto py-2">
            <li>
              <Link href="/products" data-testid="link-all-products">
                <Button variant="ghost" size="sm" className="font-medium">
                  All Products
                </Button>
              </Link>
            </li>
            {topCategories.map((category) => (
              <li key={category.id}>
                <Link href={`/category/${category.slug}`} data-testid={`link-category-${category.slug}`}>
                  <Button variant="ghost" size="sm">
                    {category.name}
                  </Button>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </header>
  );
}
