import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ShoppingCart, Heart, Star, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isHovered, setIsHovered] = useState(false);

  const price = parseFloat(product.price);
  const compareAtPrice = product.compareAtPrice ? parseFloat(product.compareAtPrice) : null;
  const discountPercent = compareAtPrice ? Math.round((1 - price / compareAtPrice) * 100) : 0;
  const imageUrl = product.images?.[0] || "/placeholder-product.jpg";
  const hoverImageUrl = product.images?.[1] || imageUrl;

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    addToCart.mutate(
      { productId: product.id, quantity: 1 },
      {
        onSuccess: () => {
          toast({
            title: "Added to cart",
            description: `${product.name} has been added to your cart.`,
          });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to add item to cart. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  const inStock = (product.stock ?? 0) > 0;

  const handleCardClick = () => {
    navigate(`/product/${product.slug}`);
  };

  return (
    <div onClick={handleCardClick}>
      <Card 
        className="group overflow-visible border hover-elevate cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        data-testid={`product-card-${product.id}`}
      >
      <div className="relative aspect-square overflow-hidden rounded-t-lg bg-muted">
        {/* Main image with hover effect */}
        <img
          src={isHovered ? hoverImageUrl : imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-all duration-300 group-hover:scale-105"
        />

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {discountPercent > 0 && (
            <Badge variant="destructive" className="text-xs">
              -{discountPercent}%
            </Badge>
          )}
          {product.featured && (
            <Badge className="text-xs bg-chart-4 text-white">
              Featured
            </Badge>
          )}
          {!inStock && (
            <Badge variant="secondary" className="text-xs">
              Out of Stock
            </Badge>
          )}
        </div>

        {/* Quick actions overlay */}
        <div 
          className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2"
        >
          <Button
            variant="secondary"
            size="icon"
            className="h-10 w-10"
            onClick={handleAddToCart}
            disabled={!inStock || addToCart.isPending}
            data-testid={`button-add-to-cart-${product.id}`}
          >
            <ShoppingCart className="h-5 w-5" />
          </Button>
          <Link href={`/product/${product.slug}`}>
            <Button 
              variant="secondary" 
              size="icon" 
              className="h-10 w-10" 
              data-testid={`button-view-${product.id}`}
            >
              <Eye className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>

      <CardContent className="p-4">
        {/* Brand */}
        {product.brand && (
          <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
            {product.brand}
          </p>
        )}

        {/* Product name */}
        <h3 className="font-medium text-sm line-clamp-2 mb-2 group-hover:text-primary transition-colors min-h-[2.5rem]">
          {product.name}
        </h3>

        {/* Rating placeholder */}
        <div className="flex items-center gap-1 mb-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <Star
              key={i}
              className={`h-3 w-3 ${i <= 4 ? "fill-chart-4 text-chart-4" : "text-muted"}`}
            />
          ))}
          <span className="text-xs text-muted-foreground ml-1">(24)</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="font-bold text-lg">{formatPrice(price)}</span>
          {compareAtPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPrice(compareAtPrice)}
            </span>
          )}
        </div>

        {/* Stock status */}
        {inStock ? (
          <p className="text-xs text-chart-2 mt-1">In Stock</p>
        ) : (
          <p className="text-xs text-muted-foreground mt-1">Out of Stock</p>
        )}
      </CardContent>
      </Card>
    </div>
  );
}
