import { Link } from "wouter";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/hooks/useCart";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";

interface CartSheetProps {
  onClose: () => void;
}

export function CartSheet({ onClose }: CartSheetProps) {
  const { cart, isLoading, itemCount, subtotal, updateQuantity, removeItem } = useCart();
  const { isAuthenticated } = useAuth();

  const handleUpdateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem.mutate(itemId);
    } else {
      updateQuantity.mutate({ itemId, quantity: newQuantity });
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  if (isLoading) {
    return (
      <SheetContent className="w-full sm:max-w-md flex flex-col">
        <SheetHeader>
          <SheetTitle>Shopping Cart</SheetTitle>
        </SheetHeader>
        <div className="flex-1 py-4 space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex gap-4">
              <Skeleton className="w-20 h-20 rounded-md" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-8 w-24" />
              </div>
            </div>
          ))}
        </div>
      </SheetContent>
    );
  }

  if (!cart?.items?.length) {
    return (
      <SheetContent className="w-full sm:max-w-md flex flex-col">
        <SheetHeader>
          <SheetTitle>Shopping Cart</SheetTitle>
        </SheetHeader>
        <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
            <ShoppingBag className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Your cart is empty</h3>
          <p className="text-muted-foreground text-sm mb-6 max-w-[200px]">
            Looks like you haven't added anything to your cart yet.
          </p>
          <Button asChild onClick={onClose} data-testid="button-continue-shopping">
            <Link href="/products">
              Start Shopping
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </SheetContent>
    );
  }

  return (
    <SheetContent className="w-full sm:max-w-md flex flex-col">
      <SheetHeader>
        <SheetTitle>Shopping Cart ({itemCount} items)</SheetTitle>
      </SheetHeader>

      <ScrollArea className="flex-1 -mx-6 px-6">
        <div className="space-y-4 py-4">
          {cart.items.map((item) => {
            const price = parseFloat(item.product.price);
            const modifier = item.variant ? parseFloat(item.variant.priceModifier || "0") : 0;
            const itemPrice = price + modifier;
            const itemTotal = itemPrice * item.quantity;
            const imageUrl = item.product.images?.[0] || "/placeholder-product.jpg";

            return (
              <div key={item.id} className="flex gap-4" data-testid={`cart-item-${item.id}`}>
                <Link href={`/product/${item.product.slug}`} onClick={onClose}>
                  <div className="w-20 h-20 rounded-md overflow-hidden bg-muted shrink-0">
                    <img
                      src={imageUrl}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Link>
                <div className="flex-1 min-w-0">
                  <Link href={`/product/${item.product.slug}`} onClick={onClose}>
                    <h4 className="font-medium text-sm line-clamp-2 hover:text-primary transition-colors">
                      {item.product.name}
                    </h4>
                  </Link>
                  {item.variant && (
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {item.variant.name}: {item.variant.value}
                    </p>
                  )}
                  <p className="font-semibold text-sm mt-1">{formatPrice(itemTotal)}</p>
                  
                  <div className="flex items-center gap-2 mt-2">
                    <div className="flex items-center border rounded-md">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                        disabled={updateQuantity.isPending || removeItem.isPending}
                        data-testid={`button-decrease-${item.id}`}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                        disabled={updateQuantity.isPending}
                        data-testid={`button-increase-${item.id}`}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      onClick={() => removeItem.mutate(item.id)}
                      disabled={removeItem.isPending}
                      data-testid={`button-remove-${item.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>

      <div className="border-t pt-4 mt-auto space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="font-medium">{formatPrice(subtotal)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Shipping</span>
            <span className="font-medium">{subtotal >= 50 ? "Free" : formatPrice(9.99)}</span>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <span className="font-semibold">Total</span>
            <span className="font-bold text-lg">
              {formatPrice(subtotal >= 50 ? subtotal : subtotal + 9.99)}
            </span>
          </div>
        </div>

        {subtotal < 50 && (
          <p className="text-xs text-muted-foreground text-center">
            Add {formatPrice(50 - subtotal)} more for free shipping!
          </p>
        )}

        {isAuthenticated ? (
          <Button asChild className="w-full" size="lg" onClick={onClose} data-testid="button-checkout">
            <Link href="/checkout">
              Proceed to Checkout
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        ) : (
          <Button asChild className="w-full" size="lg" data-testid="button-login-checkout">
            <a href="/api/login">
              Sign in to Checkout
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        )}

        <Button variant="outline" className="w-full" onClick={onClose} asChild data-testid="button-continue-shopping">
          <Link href="/products">Continue Shopping</Link>
        </Button>
      </div>
    </SheetContent>
  );
}
