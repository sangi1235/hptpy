import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient, getQueryFn } from "@/lib/queryClient";
import type { CartWithItems } from "@shared/schema";

export function useCart() {
  const { data: cart, isLoading } = useQuery<CartWithItems>({
    queryKey: ["/api/cart"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const addToCart = useMutation({
    mutationFn: async ({ productId, variantId, quantity }: { productId: number; variantId?: number; quantity: number }) => {
      return apiRequest("POST", "/api/cart/items", { productId, variantId, quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const updateQuantity = useMutation({
    mutationFn: async ({ itemId, quantity }: { itemId: number; quantity: number }) => {
      return apiRequest("PATCH", `/api/cart/items/${itemId}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const removeItem = useMutation({
    mutationFn: async (itemId: number) => {
      return apiRequest("DELETE", `/api/cart/items/${itemId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const clearCart = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", "/api/cart");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const itemCount = cart?.items?.reduce((sum, item) => sum + item.quantity, 0) ?? 0;
  
  const subtotal = cart?.items?.reduce((sum, item) => {
    const price = parseFloat(item.product.price);
    const modifier = item.variant ? parseFloat(item.variant.priceModifier || "0") : 0;
    return sum + (price + modifier) * item.quantity;
  }, 0) ?? 0;

  return {
    cart,
    isLoading,
    itemCount,
    subtotal,
    addToCart,
    updateQuantity,
    removeItem,
    clearCart,
  };
}
