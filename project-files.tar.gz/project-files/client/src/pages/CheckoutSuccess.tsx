import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function CheckoutSuccess() {
  const [, navigate] = useLocation();

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  useEffect(() => {
    // Auto-redirect to orders after 3 seconds
    const timer = setTimeout(() => {
      navigate("/orders");
    }, 3000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-chart-2" />
          </div>
          <CardTitle className="text-2xl">Payment Successful!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2 text-center">
            <p className="text-muted-foreground">
              Thank you for your purchase, <span className="font-semibold">{user?.firstName || "Customer"}</span>!
            </p>
            <p className="text-sm text-muted-foreground">
              A confirmation email has been sent to {user?.email}
            </p>
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <p className="text-sm font-medium">What happens next?</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>✓ Order confirmation email sent</li>
              <li>✓ Track your order status</li>
              <li>✓ Estimated delivery in 5-7 business days</li>
            </ul>
          </div>

          <div className="flex flex-col gap-2">
            <Button
              onClick={() => navigate("/orders")}
              className="w-full"
              data-testid="button-view-orders"
            >
              View My Orders
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/products")}
              className="w-full"
              data-testid="button-continue-shopping"
            >
              Continue Shopping
            </Button>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            Redirecting to orders in 3 seconds...
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
