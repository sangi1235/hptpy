import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

export default function CheckoutCancel() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <AlertCircle className="h-16 w-16 text-chart-1" />
          </div>
          <CardTitle className="text-2xl">Payment Cancelled</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2 text-center">
            <p className="text-muted-foreground">
              Your payment has been cancelled.
            </p>
            <p className="text-sm text-muted-foreground">
              No charges have been made to your account.
            </p>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm font-medium mb-2">Your cart is still saved</p>
            <p className="text-sm text-muted-foreground">
              All items remain in your cart. You can review and continue checkout whenever you're ready.
            </p>
          </div>

          <div className="flex flex-col gap-2">
            <Button
              onClick={() => navigate("/checkout")}
              className="w-full"
              data-testid="button-retry-checkout"
            >
              Return to Checkout
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/products")}
              className="w-full"
              data-testid="button-back-shopping"
            >
              Back to Shopping
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
