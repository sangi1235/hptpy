import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { Header } from "@/components/layout/Header";
import { ProductGrid } from "@/components/products/ProductGrid";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product, Category as CategoryType } from "@shared/schema";

export default function Category() {
  const [, params] = useRoute("/category/:slug");
  const slug = params?.slug;

  const { data: categories } = useQuery<CategoryType[]>({
    queryKey: ["/api/categories"],
  });

  const { data: category, isLoading: categoryLoading } = useQuery<CategoryType>({
    queryKey: ["/api/categories", slug],
    enabled: !!slug,
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", { categorySlug: slug }],
    enabled: !!slug,
  });

  const parentCategory = category?.parentId 
    ? categories?.find(c => c.id === category.parentId) 
    : null;

  const subcategories = categories?.filter(c => c.parentId === category?.id) || [];

  if (categoryLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header categories={categories} />
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-48 rounded-lg mb-8" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <Skeleton key={i} className="aspect-square rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen bg-background">
        <Header categories={categories} />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Category Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The category you're looking for doesn't exist.
          </p>
          <Link href="/products" className="text-primary hover:underline">
            Browse all products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header categories={categories} />

      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-foreground transition-colors" data-testid="breadcrumb-home">
            Home
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/products" className="hover:text-foreground transition-colors" data-testid="breadcrumb-products">
            Products
          </Link>
          {parentCategory && (
            <>
              <ChevronRight className="h-4 w-4" />
              <Link 
                href={`/category/${parentCategory.slug}`}
                className="hover:text-foreground transition-colors"
                data-testid="breadcrumb-parent-category"
              >
                {parentCategory.name}
              </Link>
            </>
          )}
          <ChevronRight className="h-4 w-4" />
          <span className="text-foreground font-medium">{category.name}</span>
        </nav>

        {/* Category Header */}
        <div className="relative rounded-lg overflow-hidden mb-8 bg-gradient-to-br from-primary/10 via-background to-accent/20">
          {category.imageUrl && (
            <div className="absolute inset-0">
              <img
                src={category.imageUrl}
                alt={category.name}
                className="w-full h-full object-cover opacity-20"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
            </div>
          )}
          <div className="relative p-8 md:p-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{category.name}</h1>
            {category.description && (
              <p className="text-muted-foreground max-w-2xl">{category.description}</p>
            )}
            <p className="text-sm text-muted-foreground mt-4">
              {products?.length || 0} products found
            </p>
          </div>
        </div>

        {/* Subcategories */}
        {subcategories.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold mb-4">Subcategories</h2>
            <div className="flex flex-wrap gap-2">
              {subcategories.map((sub) => (
                <Link
                  key={sub.id}
                  href={`/category/${sub.slug}`}
                  className="px-4 py-2 rounded-full border bg-card hover-elevate transition-colors"
                  data-testid={`link-subcategory-${sub.slug}`}
                >
                  {sub.name}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Products */}
        <ProductGrid 
          products={products} 
          isLoading={productsLoading}
          emptyMessage={`No products found in ${category.name}`}
        />
      </div>
    </div>
  );
}
