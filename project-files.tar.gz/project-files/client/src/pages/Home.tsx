import { Link } from "wouter";
import { ArrowRight, ChevronRight, Package, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/Header";
import { ProductGrid } from "@/components/products/ProductGrid";
import { useAuth } from "@/hooks/useAuth";
import type { Product, Category, OrderWithItems } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();

  const { data: featuredProducts, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", { featured: true, limit: 8 }],
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: recentOrders } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders", { limit: 3 }],
  });

  const topCategories = categories?.filter(c => !c.parentId).slice(0, 6) || [];

  const formatPrice = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(num);
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header categories={categories} />

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Banner */}
        <div className="bg-gradient-to-br from-primary/10 via-background to-accent/20 rounded-lg p-6 md:p-8 mb-8">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                Welcome back, {user?.firstName || "Shopper"}!
              </h1>
              <p className="text-muted-foreground max-w-xl">
                Discover our latest products and exclusive deals. Start shopping now and enjoy free shipping on orders over $50.
              </p>
            </div>
            <div className="flex gap-3">
              <Button asChild data-testid="button-shop-now">
                <Link href="/products">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              {user?.isAdmin && (
                <Button variant="outline" asChild data-testid="button-admin-dashboard">
                  <Link href="/admin">Admin Dashboard</Link>
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Categories Quick Links */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Quick Categories</h2>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/products">
                    View All
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {topCategories.map((category) => (
                  <Link
                    key={category.id}
                    href={`/category/${category.slug}`}
                    data-testid={`quick-category-${category.slug}`}
                  >
                    <Card className="hover-elevate text-center">
                      <CardContent className="p-4">
                        <div className="w-12 h-12 mx-auto rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                          <span className="text-lg font-bold text-primary">
                            {category.name[0]}
                          </span>
                        </div>
                        <p className="text-sm font-medium truncate">{category.name}</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>

            {/* Featured Products */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Featured Products</h2>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/products?featured=true">
                    View All
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <ProductGrid 
                products={featuredProducts?.slice(0, 4)} 
                isLoading={productsLoading} 
              />
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Orders */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Recent Orders</h3>
                  <Button variant="ghost" size="sm" asChild>
                    <Link href="/orders">View All</Link>
                  </Button>
                </div>
                {!recentOrders?.length ? (
                  <div className="text-center py-6">
                    <Package className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">No orders yet</p>
                    <Button variant="link" size="sm" asChild className="mt-2">
                      <Link href="/products">Start shopping</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentOrders.map((order) => (
                      <Link
                        key={order.id}
                        href={`/order/${order.id}`}
                        className="flex items-center gap-3 p-3 rounded-lg hover-elevate"
                        data-testid={`recent-order-${order.id}`}
                      >
                        <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center">
                          <Package className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm">Order #{order.id}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(order.createdAt!)} - {order.items?.length || 0} items
                          </p>
                        </div>
                        <p className="font-medium text-sm">{formatPrice(order.total)}</p>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats for Admin */}
            {user?.isAdmin && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">Quick Actions</h3>
                  </div>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/admin/products/new">
                        <Package className="h-4 w-4 mr-2" />
                        Add New Product
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/admin/orders">
                        <Package className="h-4 w-4 mr-2" />
                        Manage Orders
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
