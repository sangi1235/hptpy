import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Filter, SlidersHorizontal, Grid, List, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Header } from "@/components/layout/Header";
import { ProductGrid } from "@/components/products/ProductGrid";
import type { Product, Category } from "@shared/schema";

interface ProductFilters {
  search?: string;
  categoryId?: number;
  minPrice?: number;
  maxPrice?: number;
  brands?: string[];
  inStock?: boolean;
  featured?: boolean;
  sort?: string;
}

export default function Products() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  
  const [filters, setFilters] = useState<ProductFilters>({
    search: searchParams.get("search") || undefined,
    categoryId: searchParams.get("category") ? parseInt(searchParams.get("category")!) : undefined,
    sort: searchParams.get("sort") || "newest",
  });
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", filters],
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const topCategories = categories?.filter(c => !c.parentId) || [];

  const updateFilter = (key: keyof ProductFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({ sort: "newest" });
    setPriceRange([0, 1000]);
  };

  const activeFilterCount = Object.entries(filters).filter(
    ([key, value]) => key !== "sort" && value !== undefined && value !== ""
  ).length + (priceRange[0] > 0 || priceRange[1] < 1000 ? 1 : 0);

  const FilterSidebar = () => (
    <div className="space-y-6">
      {/* Category Filter */}
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full">
          <h3 className="font-semibold">Categories</h3>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-4 space-y-2">
          {topCategories.map((category) => (
            <label
              key={category.id}
              className="flex items-center gap-2 cursor-pointer text-sm hover:text-primary transition-colors"
            >
              <Checkbox
                checked={filters.categoryId === category.id}
                onCheckedChange={(checked) =>
                  updateFilter("categoryId", checked ? category.id : undefined)
                }
                data-testid={`filter-category-${category.id}`}
              />
              {category.name}
            </label>
          ))}
        </CollapsibleContent>
      </Collapsible>

      {/* Price Filter */}
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full">
          <h3 className="font-semibold">Price Range</h3>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-4 space-y-4">
          <Slider
            value={priceRange}
            onValueChange={(value) => setPriceRange(value as [number, number])}
            max={1000}
            step={10}
            className="w-full"
            data-testid="filter-price-slider"
          />
          <div className="flex items-center gap-2">
            <Input
              type="number"
              value={priceRange[0]}
              onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
              className="h-8 text-sm"
              placeholder="Min"
              data-testid="input-min-price"
            />
            <span className="text-muted-foreground">-</span>
            <Input
              type="number"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000])}
              className="h-8 text-sm"
              placeholder="Max"
              data-testid="input-max-price"
            />
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Availability Filter */}
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full">
          <h3 className="font-semibold">Availability</h3>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-4 space-y-2">
          <label className="flex items-center gap-2 cursor-pointer text-sm">
            <Checkbox
              checked={filters.inStock === true}
              onCheckedChange={(checked) => updateFilter("inStock", checked ? true : undefined)}
              data-testid="filter-in-stock"
            />
            In Stock Only
          </label>
          <label className="flex items-center gap-2 cursor-pointer text-sm">
            <Checkbox
              checked={filters.featured === true}
              onCheckedChange={(checked) => updateFilter("featured", checked ? true : undefined)}
              data-testid="filter-featured"
            />
            Featured Products
          </label>
        </CollapsibleContent>
      </Collapsible>

      {/* Clear Filters */}
      {activeFilterCount > 0 && (
        <Button
          variant="outline"
          className="w-full"
          onClick={clearFilters}
          data-testid="button-clear-filters"
        >
          Clear All Filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header categories={categories} />

      <div className="container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">All Products</h1>
          <p className="text-muted-foreground">
            {products?.length || 0} products found
          </p>
        </div>

        {/* Active Filters */}
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            {filters.categoryId && (
              <Badge variant="secondary" className="gap-1">
                Category: {topCategories.find(c => c.id === filters.categoryId)?.name}
                <button onClick={() => updateFilter("categoryId", undefined)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {filters.search && (
              <Badge variant="secondary" className="gap-1">
                Search: {filters.search}
                <button onClick={() => updateFilter("search", undefined)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {filters.inStock && (
              <Badge variant="secondary" className="gap-1">
                In Stock
                <button onClick={() => updateFilter("inStock", undefined)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {filters.featured && (
              <Badge variant="secondary" className="gap-1">
                Featured
                <button onClick={() => updateFilter("featured", undefined)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>
        )}

        <div className="flex gap-8">
          {/* Desktop Sidebar */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="sticky top-28">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <SlidersHorizontal className="h-5 w-5" />
                Filters
              </h2>
              <FilterSidebar />
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Toolbar */}
            <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b">
              {/* Mobile Filter Button */}
              <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden gap-2" data-testid="button-mobile-filters">
                    <Filter className="h-4 w-4" />
                    Filters
                    {activeFilterCount > 0 && (
                      <Badge variant="secondary" className="ml-1">
                        {activeFilterCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80">
                  <SheetHeader>
                    <SheetTitle className="flex items-center gap-2">
                      <SlidersHorizontal className="h-5 w-5" />
                      Filters
                    </SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    <FilterSidebar />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Sort Select */}
              <div className="flex items-center gap-2 ml-auto">
                <Label className="hidden sm:block text-sm text-muted-foreground">Sort by:</Label>
                <Select
                  value={filters.sort}
                  onValueChange={(value) => updateFilter("sort", value)}
                >
                  <SelectTrigger className="w-[180px]" data-testid="select-sort">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="name">Name: A to Z</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Product Grid */}
            <ProductGrid products={products} isLoading={isLoading} />
          </main>
        </div>
      </div>
    </div>
  );
}
