import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Minus, Plus, ShoppingCart, Heart, Share2, Truck, Shield, 
  RefreshCcw, ChevronLeft, Star, Check, ChevronRight 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";
import { Header } from "@/components/layout/Header";
import { ProductGrid } from "@/components/products/ProductGrid";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithCategory, Category, Product } from "@shared/schema";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:slug");
  const slug = params?.slug;
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});

  const { data: product, isLoading } = useQuery<ProductWithCategory>({
    queryKey: ["/api/products", slug],
    enabled: !!slug,
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: relatedProducts } = useQuery<Product[]>({
    queryKey: ["/api/products", { categoryId: product?.categoryId, limit: 4 }],
    enabled: !!product?.categoryId,
  });

  const formatPrice = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(num);
  };

  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart.mutate(
      { productId: product.id, quantity },
      {
        onSuccess: () => {
          toast({
            title: "Added to cart",
            description: `${quantity}x ${product.name} has been added to your cart.`,
          });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "Failed to add item to cart. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header categories={categories} />
        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-4">
              <Skeleton className="aspect-square rounded-lg" />
              <div className="flex gap-2">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="w-20 h-20 rounded-md" />
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-1/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-12 w-full mt-6" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header categories={categories} />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The product you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link href="/products">Browse Products</Link>
          </Button>
        </div>
      </div>
    );
  }

  const price = parseFloat(product.price);
  const compareAtPrice = product.compareAtPrice ? parseFloat(product.compareAtPrice) : null;
  const discountPercent = compareAtPrice ? Math.round((1 - price / compareAtPrice) * 100) : 0;
  const images = product.images?.length ? product.images : ["/placeholder-product.jpg"];
  const inStock = (product.stock ?? 0) > 0;

  const groupedVariants = product.variants?.reduce((acc, variant) => {
    if (!acc[variant.name]) {
      acc[variant.name] = [];
    }
    acc[variant.name].push(variant);
    return acc;
  }, {} as Record<string, typeof product.variants>) || {};

  const filteredRelated = relatedProducts?.filter(p => p.id !== product.id).slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <Header categories={categories} />

      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-foreground transition-colors" data-testid="breadcrumb-home">
            Home
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/products" className="hover:text-foreground transition-colors" data-testid="breadcrumb-products">
            Products
          </Link>
          {product.category && (
            <>
              <ChevronRight className="h-4 w-4" />
              <Link 
                href={`/category/${product.category.slug}`} 
                className="hover:text-foreground transition-colors"
                data-testid="breadcrumb-category"
              >
                {product.category.name}
              </Link>
            </>
          )}
          <ChevronRight className="h-4 w-4" />
          <span className="text-foreground font-medium truncate max-w-[200px]">
            {product.name}
          </span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-muted">
              <img
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
                data-testid="product-main-image"
              />
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-md overflow-hidden shrink-0 border-2 transition-colors ${
                      selectedImage === index
                        ? "border-primary"
                        : "border-transparent hover:border-muted-foreground/50"
                    }`}
                    data-testid={`product-thumbnail-${index}`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Title & Brand */}
            <div>
              {product.brand && (
                <p className="text-sm text-muted-foreground uppercase tracking-wide mb-1">
                  {product.brand}
                </p>
              )}
              <h1 className="text-2xl md:text-3xl font-bold" data-testid="product-title">
                {product.name}
              </h1>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${i <= 4 ? "fill-chart-4 text-chart-4" : "text-muted"}`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">(24 reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold" data-testid="product-price">
                {formatPrice(price)}
              </span>
              {compareAtPrice && (
                <>
                  <span className="text-lg text-muted-foreground line-through">
                    {formatPrice(compareAtPrice)}
                  </span>
                  <Badge variant="destructive">Save {discountPercent}%</Badge>
                </>
              )}
            </div>

            {/* Stock Status */}
            <div className="flex items-center gap-2">
              {inStock ? (
                <>
                  <Check className="h-4 w-4 text-chart-2" />
                  <span className="text-sm text-chart-2">In Stock ({product.stock} available)</span>
                </>
              ) : (
                <span className="text-sm text-destructive">Out of Stock</span>
              )}
            </div>

            <Separator />

            {/* Variants */}
            {Object.entries(groupedVariants).map(([name, variants]) => (
              <div key={name} className="space-y-2">
                <label className="text-sm font-medium">{name}</label>
                <div className="flex flex-wrap gap-2">
                  {variants?.map((variant) => (
                    <Button
                      key={variant.id}
                      variant={selectedVariants[name] === variant.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedVariants(prev => ({ ...prev, [name]: variant.value }))}
                      data-testid={`variant-${name}-${variant.value}`}
                    >
                      {variant.value}
                      {variant.priceModifier && parseFloat(variant.priceModifier) > 0 && (
                        <span className="ml-1 text-xs">
                          (+{formatPrice(parseFloat(variant.priceModifier))})
                        </span>
                      )}
                    </Button>
                  ))}
                </div>
              </div>
            ))}

            {/* Quantity & Add to Cart */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex items-center border rounded-md w-fit">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                  data-testid="button-decrease-quantity"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-12 text-center font-medium" data-testid="quantity-display">
                  {quantity}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setQuantity(quantity + 1)}
                  disabled={!inStock || quantity >= (product.stock ?? 0)}
                  data-testid="button-increase-quantity"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              <Button
                size="lg"
                className="flex-1"
                onClick={handleAddToCart}
                disabled={!inStock || addToCart.isPending}
                data-testid="button-add-to-cart"
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                {addToCart.isPending ? "Adding..." : "Add to Cart"}
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="flex flex-col items-center text-center p-3 rounded-lg bg-muted/50">
                <Truck className="h-5 w-5 mb-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Free Shipping</span>
              </div>
              <div className="flex flex-col items-center text-center p-3 rounded-lg bg-muted/50">
                <Shield className="h-5 w-5 mb-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Secure Payment</span>
              </div>
              <div className="flex flex-col items-center text-center p-3 rounded-lg bg-muted/50">
                <RefreshCcw className="h-5 w-5 mb-1 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Easy Returns</span>
              </div>
            </div>

            <Separator />

            {/* Description & Details */}
            <Accordion type="single" collapsible defaultValue="description">
              <AccordionItem value="description">
                <AccordionTrigger>Description</AccordionTrigger>
                <AccordionContent>
                  <p className="text-muted-foreground whitespace-pre-wrap">
                    {product.description || "No description available for this product."}
                  </p>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="shipping">
                <AccordionTrigger>Shipping & Returns</AccordionTrigger>
                <AccordionContent>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>Free standard shipping on orders over $50</li>
                    <li>Express shipping available at checkout</li>
                    <li>30-day easy returns and exchanges</li>
                    <li>Items must be unused and in original packaging</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
              {product.sku && (
                <AccordionItem value="specifications">
                  <AccordionTrigger>Specifications</AccordionTrigger>
                  <AccordionContent>
                    <dl className="text-sm space-y-2">
                      <div className="flex">
                        <dt className="text-muted-foreground w-24">SKU:</dt>
                        <dd>{product.sku}</dd>
                      </div>
                      {product.weight && (
                        <div className="flex">
                          <dt className="text-muted-foreground w-24">Weight:</dt>
                          <dd>{product.weight} kg</dd>
                        </div>
                      )}
                    </dl>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </div>
        </div>

        {/* Related Products */}
        {filteredRelated && filteredRelated.length > 0 && (
          <section className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <ProductGrid products={filteredRelated} />
          </section>
        )}
      </div>
    </div>
  );
}
